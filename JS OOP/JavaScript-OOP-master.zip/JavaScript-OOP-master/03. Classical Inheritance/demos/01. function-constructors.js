function Rect(x, y, width, height) {
	console.log('This rect is positioned at (' + x + ', ' + y + ') and has size ' + width + 'x' + height);
}

var rect1 = new Rect(5, 15, 67, 76);
var rect1 = new Rect(5, 15, 67, 76);
var rect1 = new Rect(5, 15, 67, 76);