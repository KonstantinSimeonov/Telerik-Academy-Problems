﻿(function(game){
    var game = game || {};

    game.renderer = (function () {

        var canvasId = 'canvas';

        return {

        }
    }())
}(window));