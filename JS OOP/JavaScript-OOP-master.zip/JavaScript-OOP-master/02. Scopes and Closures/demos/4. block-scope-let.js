if (false) {
  var x = 5;
  let y = 6;
}
console.log(x);
//works only if run with Babel or Traceur
console.log(y);
