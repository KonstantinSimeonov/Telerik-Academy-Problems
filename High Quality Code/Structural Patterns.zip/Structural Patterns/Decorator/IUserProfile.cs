namespace Decorator
{
    public interface IUserProfile
    {
        string Username { get; set; }
        string Password { get; set; }
    }
}