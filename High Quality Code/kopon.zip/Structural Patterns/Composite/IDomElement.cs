﻿namespace Composite
{
    public interface IDomElement
    {
        string Render(int depth);
    }
}
