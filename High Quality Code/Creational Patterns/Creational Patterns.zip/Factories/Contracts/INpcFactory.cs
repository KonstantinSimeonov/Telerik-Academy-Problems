﻿namespace Factories.Contracts
{
    public interface INpcFactory
    {
        INpc Create(string name);
    }
}
