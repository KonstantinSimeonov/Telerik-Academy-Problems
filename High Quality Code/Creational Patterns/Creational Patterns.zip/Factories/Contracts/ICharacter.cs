﻿namespace Factories.Contracts
{
    public interface ICharacter
    {
        void UseSpecialAbility();
    }
}