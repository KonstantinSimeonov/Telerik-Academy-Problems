﻿namespace Factories.Contracts
{
    public interface INpc
    {
        string Name { get; }
    }
}