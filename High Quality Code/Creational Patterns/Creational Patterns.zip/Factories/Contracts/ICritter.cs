﻿namespace Factories.Contracts
{
    public interface ICritter
    {
        string Type { get; }
    }
}